#include "ann/funtions.h"
#include <cinttypes>
#include <cstdint>
#include <cstdio>
#include <limits>



xt::xarray<double> softmax(xt::xarray<double> X, int axis){
    /*TODO: Your code is here*/
}
