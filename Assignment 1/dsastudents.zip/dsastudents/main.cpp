#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include "list/listheader.h"

using namespace std;


int main(int argc, char** argv) {
    cout << "Assignment-1" << endl;
    return 0;
}

