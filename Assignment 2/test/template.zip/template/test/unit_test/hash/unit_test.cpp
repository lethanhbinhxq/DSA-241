#include "unit_test.hpp"

map<string, bool (UNIT_TEST_Hash::*)()> UNIT_TEST_Hash::TESTS;

// TODO unit test new