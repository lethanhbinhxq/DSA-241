#include "unit_test.hpp"

map<string, bool (UNIT_TEST_Heap::*)()> UNIT_TEST_Heap::TESTS;

// TODO unit test new