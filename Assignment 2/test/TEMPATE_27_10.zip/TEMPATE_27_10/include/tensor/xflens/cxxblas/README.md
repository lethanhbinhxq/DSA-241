# FLENS: Flexible Library for Efficient Numerical Solutions

This folder contains slightly modified code from the [FLENS Library](https://github.com/michael-lehn/FLENS).
The FLENS library is published under a BSD-3-Clause license.
